# Asegúrate de que Pillow esté instalado: pip install Pillow
import requests
from dotenv import load_dotenv
import os
import tkinter as tk
from tkinter import ttk, scrolledtext
import webbrowser
from PIL import Image, ImageTk  # Pillow debe estar instalado
from io import BytesIO

load_dotenv()

API_KEY = os.getenv("API_KEY_SEARCH_GOOGLE")
SEARCH_ENGINE_ID = os.getenv("SEARCH_ENGINE_ID")

if not API_KEY or not SEARCH_ENGINE_ID:
    raise ValueError("Las variables de entorno API_KEY_SEARCH_GOOGLE y SEARCH_ENGINE_ID deben estar configuradas correctamente.")

def open_link(event):
    """
    Abre un enlace en el navegador predeterminado.
    """
    try:
        # Obtener el texto del enlace en la línea actual
        url = results_text.get("current linestart", "current lineend").strip()
        if url.startswith("Link: "):
            url = url.replace("Link: ", "").strip()
        if url:
            webbrowser.open_new_tab(url)
        else:
            print("URL no válida.")
    except Exception as e:
        print(f"Error al abrir el enlace: {e}")

def clear_results():
    """
    Limpia el contenido del widget de texto y libera referencias a imágenes.
    """
    results_text.delete(1.0, tk.END)
    for widget in results_text.winfo_children():
        widget.destroy()

def search_google():
    query = search_entry.get()
    page = 1
    lang = "lang_es"
    url = f"https://www.googleapis.com/customsearch/v1?key={API_KEY}&cx={SEARCH_ENGINE_ID}&q={query}&start={page}&lr={lang}"
    
    response = requests.get(url)
    if response.status_code != 200:
        clear_results()  # Limpiar resultados anteriores
        results_text.insert(tk.END, f"Error en la solicitud: {response.status_code} - {response.text}")
        return
    
    data = response.json()
    clear_results()  # Limpiar resultados anteriores
    if result := data.get('items', []):
        for item in result:
            title = item.get('title')
            link = item.get('link')
            snippet = item.get('snippet')
            image_url = item.get('pagemap', {}).get('cse_image', [{}])[0].get('src')

            # Mostrar título como texto
            results_text.insert(tk.END, f"Title: {title}\n", "title")
            # Mostrar enlace clicable
            results_text.insert(tk.END, f"Link: {link}\n", "link")
            results_text.insert(tk.END, f"Snippet: {snippet}\n")

            # Mostrar imagen si está disponible
            if image_url:
                try:
                    img_response = requests.get(image_url)
                    img_data = Image.open(BytesIO(img_response.content))
                    img_data.thumbnail((100, 100))  # Redimensionar imagen
                    img = ImageTk.PhotoImage(img_data)
                    img_label = tk.Label(results_text, image=img)
                    img_label.image = img  # Guardar referencia para evitar que se elimine
                    results_text.window_create(tk.END, window=img_label)
                    results_text.insert(tk.END, "\n")
                except Exception as e:
                    results_text.insert(tk.END, f"Error al cargar imagen: {e}\n")

            results_text.insert(tk.END, "-" * 80 + "\n")
    else:
        results_text.insert(tk.END, "No se encontraron resultados.\n")

# Crear la ventana principal
root = tk.Tk()
root.title("Buscador de Google")
root.geometry("800x600")  # Establece un tamaño inicial para la ventana

# Crear los widgets
frame = ttk.Frame(root, padding="10")
frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

search_label = ttk.Label(frame, text="Consulta:")
search_label.grid(row=0, column=0, sticky=tk.W)

search_entry = ttk.Entry(frame, width=50)
search_entry.grid(row=0, column=1, sticky=(tk.W, tk.E))

search_button = ttk.Button(frame, text="Buscar", command=search_google)
search_button.grid(row=0, column=2, sticky=tk.W)

results_text = scrolledtext.ScrolledText(frame, wrap=tk.WORD, width=80, height=20)
results_text.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E))

# Configurar estilos para enlaces clicables
results_text.tag_configure("link", foreground="blue", underline=True)
results_text.tag_bind("link", "<Button-1>", open_link)

# Ajustar el tamaño de la ventana
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)
frame.columnconfigure(1, weight=1)

# Iniciar el bucle principal de la interfaz
try:
    root.mainloop()
except Exception as e:
    print(f"Error al iniciar la interfaz gráfica: {e}")